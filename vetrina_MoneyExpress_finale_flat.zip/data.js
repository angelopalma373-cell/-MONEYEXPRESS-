// Lista prodotti — MoneyExpress
const PRODUCTS = [
  { id:1, name:"6x Banconote 50€", price:29.99, emoji:"💶", desc:"Totale 300€ in banconote da 50" },
  { id:2, name:"10x Banconote 50€", price:49.99, emoji:"💶", desc:"Totale 500€ in banconote da 50" },
  { id:3, name:"20x Banconote 50€", price:89.99, emoji:"💶", desc:"Totale 1000€ in banconote da 50" }
];
