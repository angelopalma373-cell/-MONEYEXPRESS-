const grid = document.getElementById('grid');
const yearSpan = document.getElementById('year');
yearSpan.textContent = new Date().getFullYear();

const formatPrice = (n) => n.toLocaleString('it-IT', { style:'currency', currency:'EUR' });

function render(){
  grid.innerHTML = '';
  for (const p of PRODUCTS){
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `
      <div class="thumb">${p.emoji || '📦'}</div>
      <h3>${p.name}</h3>
      <p class="desc">${p.desc || ''}</p>
      <div class="price">${formatPrice(p.price)}</div>
    `;
    grid.appendChild(card);
  }
}

render();
